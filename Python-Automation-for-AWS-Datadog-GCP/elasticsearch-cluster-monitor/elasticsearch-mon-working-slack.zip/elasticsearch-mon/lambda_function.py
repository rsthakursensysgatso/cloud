import sys
#sys.path.append('elasticsearch/elastic-lambda/elasticsearch-mon')
sys.path.append('elasticsearch-mon')
import requests, json
from urllib.request import Request, urlopen

def notification():
	p = subprocess.Popen(['curl', '-X', 'POST', '-H', 'Content-type: application/json', '--data', '{"text":"Elasticsearch Cluster Testing"}', 'https://hooks.slack.com/services/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'], stdout=subprocess.PIPE)
	out, err = p.communicate()
	print(out)


## elk stack api status endpoiint

def elasticsearch(event, context):
	url="http://internal-test-elasticsearch-1561359084.eu-west-1.elb.amazonaws.com:9200/_cluster/health?pretty=true"
	r=requests.get(url)
	data=r.json()
	status=data['status']
	print (data['status'])
	if not data['status'] == "green":
		notification()
		print('alarmmessage')
	else:
		print('everthing OKK!!!!!!!')
