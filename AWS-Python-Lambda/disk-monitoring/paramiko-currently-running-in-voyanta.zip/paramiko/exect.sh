#!/bin/bash

./disk-alert.sh &
