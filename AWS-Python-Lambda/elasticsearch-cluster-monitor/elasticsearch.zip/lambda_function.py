#!/usr/bin/python3.6

import hipchat
import requests, json
from urllib.request import Request, urlopen

def notification():
	V2TOKEN = 'vEXywxQIIoHQpXjtVsdksy5gJ5JTsaliV5TCw7j5'
	ROOMID = 4779381

	url = 'https://api.hipchat.com/v2/room/{}/notification'.format(ROOMID)
	headers = {
	    "content-type": "application/json",
	    "authorization": "Bearer {}".format(V2TOKEN)}
	datastr = json.dumps({
	    'message': "Elasticsearch Unhealthy",
	    'color': 'purple',
	    'message_format': 'html',
	    'notify': True,
	    'from': 'Lambda'})
	request = Request(url, headers=headers, data=datastr.encode('utf-8'))
	uo = urlopen(request)
	rawresponse = ''.join(uo)
	uo.close()
	assert uo.code == 204

## elk stack api status endpoiint

#url="http://localhost:9200/_cluster/health?pretty=true"
url="http://internal-test-elasticsearch-1561359084.eu-west-1.elb.amazonaws.com:9200/_cluster/health?pretty=true"
r = requests.get(url)
data=r.json()
status=data['status']
print (data['status'])

if data['status'] == "yellow":
	notification()
	print('Elasticsearch Cluster Live is unhealthy')
else:
	print('everthing OKK!!!!!!!')
